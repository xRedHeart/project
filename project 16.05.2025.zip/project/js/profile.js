document.addEventListener('DOMContentLoaded', function() {
    const submitBtn = document.getElementById('submitAd');
    const adForm = document.getElementById('adForm');
    let currentPage = 1;
    const perPage = 10;
    const userId = 1; // Замените на реальный ID из сессии
    
    // основной контейнер для объявлений
    const adsContainer = document.querySelector('main > .alert') || createAdsContainer();
    
    function createAdsContainer() {
        const container = document.createElement('div');
        container.className = 'alert alert-info';
        container.textContent = 'У вас пока нет объявлений.';
        document.querySelector('main').appendChild(container);
        return container;
    }

    // инициализация пагинации
    function initPagination() {
        const paginationHTML = `
            <nav aria-label="Page navigation" class="mt-4">
                <ul class="pagination justify-content-center" id="profilePagination"></ul>
            </nav>
        `;
        adsContainer.insertAdjacentHTML('afterend', paginationHTML);
    }

    // загрузка объявлений
    async function loadUserAds() {
        try {
            adsContainer.innerHTML = `
                <div class="text-center my-3">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Загрузка...</span>
                    </div>
                </div>
            `;

            const response = await fetch(`/api/ads.php?user_id=${userId}&page=${currentPage}&per_page=${perPage}`);
            
            if (!response.ok) throw new Error('Ошибка сети');
            
            const data = await response.json();
            
            if (!data.success) throw new Error(data.message || 'Ошибка сервера');

            if (data.ads && data.ads.length > 0) {
                renderAds(data.ads);
                if (!document.getElementById('profilePagination')) {
                    initPagination();
                }
                renderPagination(data.total);
            } else {
                adsContainer.innerHTML = '<div class="alert alert-info">У вас пока нет объявлений.</div>';
                const pagination = document.getElementById('profilePagination');
                if (pagination) pagination.innerHTML = '';
            }
        } catch (error) {
            console.error('Ошибка:', error);
            adsContainer.innerHTML = `
                <div class="alert alert-danger">
                    Ошибка загрузки: ${error.message}
                </div>
            `;
        }
    }

    // отрисовка объявлений
    function renderAds(ads) {
        adsContainer.innerHTML = '';
        
        const row = document.createElement('div');
        row.className = 'row row-cols-1 g-3';
        
        ads.forEach(ad => {
            const col = document.createElement('div');
            col.className = 'col';
            col.innerHTML = `
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h5 class="card-title">${ad.title}</h5>
                            <span class="badge bg-primary">${ad.category}</span>
                        </div>
                        <p class="card-text">${ad.description || 'Нет описания'}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <small class="text-muted">
                                ${new Date(ad.created_at).toLocaleDateString('ru-RU')}
                            </small>
                            <h5 class="text-primary mb-0">${parseInt(ad.price).toLocaleString('ru-RU')} ₽</h5>
                        </div>
                        <div class="mt-2">
                            <a href="ad.html?id=${ad.id}" class="btn btn-sm btn-outline-primary">Просмотреть</a>
                            <button class="btn btn-sm btn-outline-danger">Удалить</button>
                        </div>
                    </div>
                </div>
            `;
            row.appendChild(col);
        });
        
        adsContainer.appendChild(row);
    }

    // отрисовка пагинации
    function renderPagination(total) {
        const totalPages = Math.ceil(total / perPage);
        const pagination = document.getElementById('profilePagination');
        
        if (!pagination || totalPages <= 1) {
            if (pagination) pagination.innerHTML = '';
            return;
        }

        let html = '';
        const maxVisiblePages = 5;
        let startPage = Math.max(1, currentPage - 2);
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

        // кнопка "назад"
        html += `
            <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${currentPage - 1}" aria-label="Назад">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
        `;

        // первая страница
        if (startPage > 1) {
            html += `
                <li class="page-item">
                    <a class="page-link" href="#" data-page="1">1</a>
                </li>
                ${startPage > 2 ? '<li class="page-item disabled"><span class="page-link">...</span></li>' : ''}
            `;
        }

        // страницы
        for (let i = startPage; i <= endPage; i++) {
            html += `
                <li class="page-item ${i === currentPage ? 'active' : ''}">
                    <a class="page-link" href="#" data-page="${i}">${i}</a>
                </li>
            `;
        }

        // последняя страница
        if (endPage < totalPages) {
            html += `
                ${endPage < totalPages - 1 ? '<li class="page-item disabled"><span class="page-link">...</span></li>' : ''}
                <li class="page-item">
                    <a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a>
                </li>
            `;
        }

        // кнопка "вперед"
        html += `
            <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${currentPage + 1}" aria-label="Вперед">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        `;

        pagination.innerHTML = html;

        // обработчики событий
        document.querySelectorAll('#profilePagination [data-page]').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const page = parseInt(this.getAttribute('data-page'));
                if (!isNaN(page) && page !== currentPage) {
                    currentPage = page;
                    loadUserAds();
                    window.scrollTo({top: 0, behavior: 'smooth'});
                }
            });
        });
    }

    // обработчик отправки формы
    submitBtn.addEventListener('click', async function(e) {
        e.preventDefault();
        
        if (!adForm.checkValidity()) {
            adForm.classList.add('was-validated');
            return;
        }
        
        const formData = new FormData();
        formData.append('title', document.getElementById('adTitle').value);
        formData.append('description', document.getElementById('adDescription').value);
        formData.append('type', document.querySelector('.type-select').value);
        formData.append('category', document.querySelector('.category-select').value);
        formData.append('price', document.getElementById('adPrice').value);
        formData.append('user_id', userId);
        
        const imageFile = document.getElementById('adImage').files[0];
        if (imageFile) formData.append('image', imageFile);

        try {
            const response = await fetch('/api/ads.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                Swal.fire({
                    title: 'Успех!',
                    text: 'Объявление успешно создано',
                    icon: 'success'
                }).then(() => {
                    const modal = bootstrap.Modal.getInstance(document.getElementById('newAdModal'));
                    modal.hide();
                    adForm.reset();
                    adForm.classList.remove('was-validated');
                    currentPage = 1;
                    loadUserAds();
                });
            } else {
                throw new Error(data.message || 'Ошибка при создании объявления');
            }
        } catch (error) {
            Swal.fire({
                title: 'Ошибка',
                text: error.message,
                icon: 'error'
            });
        }
    });

    loadUserAds();
});