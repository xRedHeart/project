document.addEventListener('DOMContentLoaded', function() {
    const submitBtn = document.getElementById('submitAd');
    const adForm = document.getElementById('adForm');
    
    submitBtn.addEventListener('click', function() {
        if (!adForm.checkValidity()) {
            adForm.classList.add('was-validated');
            return;
        }
        
        const formData = new FormData();
        formData.append('title', document.getElementById('adTitle').value);
        formData.append('description', document.getElementById('adDescription').value);
        formData.append('type', document.querySelector('.type-select').value);
        formData.append('category', document.querySelector('.category-select').value);
        formData.append('price', document.getElementById('adPrice').value);
        
        const imageFile = document.getElementById('adImage').files[0];
        if (imageFile) {
            formData.append('image', imageFile);
        }
        
        // Здесь должен быть ID текущего пользователя (из сессии или другого места)
        formData.append('user_id', 1); // Временное значение, нужно заменить на реальное
        
        createAd(formData);
    });
    
    async function createAd(formData) {
        try {
            const response = await fetch('/api/ads.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                Swal.fire({
                    title: 'Успех!',
                    text: 'Объявление успешно создано',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(() => {
                    const modal = bootstrap.Modal.getInstance(document.getElementById('newAdModal'));
                    modal.hide();
                    adForm.reset();
                    adForm.classList.remove('was-validated');
                    updateUIAfterCreation();
                    // Можно обновить список объявлений
                    loadUserAds();
                });
            } else {
                throw new Error(data.message || 'Ошибка при создании объявления');
            }
        } catch (error) {
            Swal.fire({
                title: 'Ошибка',
                text: error.message,
                icon: 'error'
            });
        }
    }
    
    // Функция для загрузки объявлений пользователя
    async function loadUserAds() {
        try {
            const response = await fetch(`/api/ads.php?user_id=1`); // Заменить на реальный ID пользователя
            const data = await response.json();
            
            if (data.success && data.ads.length > 0) {
                renderUserAds(data.ads);
            }
        } catch (error) {
            console.error('Ошибка загрузки объявлений:', error);
        }
    }
    
    // Функция для отображения объявлений пользователя
    function renderUserAds(ads) {
        const container = document.querySelector('main .alert');
        if (!container) return;
        
        container.innerHTML = '';
        
        ads.forEach(ad => {
            const adElement = document.createElement('div');
            adElement.className = 'card mb-3';
            adElement.innerHTML = `
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h5 class="card-title">${ad.title}</h5>
                        <span class="badge bg-primary">${ad.category}</span>
                    </div>
                    <p class="card-text">${ad.description || 'Нет описания'}</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted">
                            ${new Date(ad.created_at).toLocaleDateString('ru-RU')}
                        </small>
                        <h5 class="text-primary mb-0">${parseInt(ad.price).toLocaleString('ru-RU')} ₽</h5>
                    </div>
                    <div class="mt-2">
                        <a href="ad.html?id=${ad.id}" class="btn btn-sm btn-outline-primary">Просмотреть</a>
                        <button class="btn btn-sm btn-outline-danger">Удалить</button>
                    </div>
                </div>
            `;
            container.appendChild(adElement);
        });
    }
    
    // Инициализация - загружаем объявления пользователя при загрузке страницы
    loadUserAds();
    
    // Остальной код остается без изменений
    // ...
});