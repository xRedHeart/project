function toggleLogin() {
    const login = document.getElementById('login-box');
    const register = document.getElementById('register-box');
    login.style.display = (login.style.display === 'none' || login.style.display === '') ? 'block' : 'none';
    register.style.display = 'none';
}

function toggleRegister() {
    const login = document.getElementById('login-box');
    const register = document.getElementById('register-box');
    register.style.display = (register.style.display === 'none' || register.style.display === '') ? 'block' : 'none';
    login.style.display = 'none';
}

document.addEventListener('click', function (e) {
    if (!e.target.closest('.auth-box') &&
        !e.target.closest('button[onclick="toggleLogin()"]') &&
        !e.target.closest('button[onclick="toggleRegister()"]')) {
        document.getElementById('login-box').style.display = 'none';
        document.getElementById('register-box').style.display = 'none';
    }
});

window.addEventListener('DOMContentLoaded', () => {
    const isLoggedIn = true; 
    const guest = document.getElementById('guest-actions');
    const userInfo = document.getElementById('user-info');

    if (isLoggedIn) {
        guest.style.display = 'none';
        userInfo.classList.remove('d-none');
        document.getElementById('user-name').textContent = 'Артем';
        document.getElementById('user-avatar').src = 'images/aNNqp9.jpeg';
    } else {
        guest.style.display = 'flex';
        userInfo.classList.add('d-none');
    }
});
