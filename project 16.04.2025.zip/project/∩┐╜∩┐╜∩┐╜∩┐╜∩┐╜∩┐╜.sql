INSERT INTO ads (title, services, products, category, price, image) VALUES
('Ремонт компьютеров', true, false, 'Электроника', 2000, 'https://example.com/computer.jpg'),
('Ноутбук HP', false, true, 'Электроника', 15000, 'https://example.com/laptop.jpg'),
('Куртка зимняя', false, true, 'Одежда', 5000, 'https://example.com/jacket.jpg'),
('Установка Windows', true, false, 'Электроника', 1000, NULL),
('Шины зимние', false, true, 'Авто', 8000, 'https://example.com/tires.jpg'),
('Ремонт iPhone', true, false, 'Электроника', 3000, NULL);