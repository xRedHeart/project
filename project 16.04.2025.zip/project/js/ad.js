document.addEventListener('DOMContentLoaded', function() {
    // Получаем ID объявления из URL
    const urlParams = new URLSearchParams(window.location.search);
    const adId = urlParams.get('id');
    
    if (!adId) {
        window.location.href = 'avitoo.html';
        return;
    }

    // Загружаем данные объявления
    loadAdData(adId);

    // Обработчик для добавления в избранное
    document.getElementById('add-to-favorites').addEventListener('click', function() {
        toggleFavorite(adId);
    });
});

async function loadAdData(adId) {
    try {
        const response = await fetch(`/api/ad.php?id=${adId}`);
        
        if (!response.ok) {
            throw new Error('Ошибка загрузки данных');
        }
        
        const data = await response.json();
        
        if (data.success) {
            renderAd(data.ad);
        } else {
            throw new Error(data.message || 'Объявление не найдено');
        }
    } catch (error) {
        console.error('Ошибка:', error);
        document.getElementById('ad-title').textContent = 'Ошибка загрузки объявления';
    }
}

function renderAd(ad) {
    document.getElementById('ad-title').textContent = ad.title;
    document.getElementById('ad-description').textContent = ad.description || 'Нет описания';
    document.getElementById('ad-price').textContent = `${parseInt(ad.price).toLocaleString('ru-RU')} ₽`;
    document.getElementById('ad-category').textContent = ad.category;
    document.getElementById('ad-type').textContent = ad.services ? 'Услуга' : 'Товар';
    document.getElementById('ad-date').textContent = `Дата публикации: ${new Date(ad.created_at).toLocaleDateString('ru-RU')}`;
    document.getElementById('ad-views').textContent = `Просмотров: ${ad.views || 0}`;
    
    document.getElementById('seller-name').textContent = ad.seller_name || 'Продавец';
    document.getElementById('seller-registration').textContent = `На сайте с ${new Date(ad.seller_since).getFullYear()}`;
    
    renderImages(ad.images);
    
    renderSpecifications(ad.specs);
}

function renderImages(images) {
    const mainImage = document.getElementById('main-image');
    const thumbnails = document.getElementById('thumbnails');
    
    if (!images || images.length === 0) {
        mainImage.innerHTML = '<img src="https://via.placeholder.com/800x600" class="img-fluid rounded" alt="Нет изображения">';
        return;
    }
    
    // Основное изображение
    mainImage.innerHTML = `<img src="uploads/${images[0]}" class="img-fluid rounded" alt="Основное изображение">`;
    
    thumbnails.innerHTML = '';
    images.forEach((img, index) => {
        const thumb = document.createElement('img');
        thumb.src = `uploads/thumb_${img}`;
        thumb.alt = `Изображение ${index + 1}`;
        thumb.classList.add('img-thumbnail');
        
        thumb.addEventListener('click', () => {
            mainImage.innerHTML = `<img src="uploads/${img}" class="img-fluid rounded" alt="Основное изображение">`;
            document.querySelectorAll('.thumbnails img').forEach(t => t.classList.remove('active'));
            thumb.classList.add('active');
        });
        
        if (index === 0) thumb.classList.add('active');
        thumbnails.appendChild(thumb);
    });
}

function renderSpecifications(specs) {
    const container = document.getElementById('ad-specs');
    container.innerHTML = '';
    
    if (!specs) return;
    
    for (const [key, value] of Object.entries(specs)) {
        const specElement = document.createElement('div');
        specElement.className = 'col-md-6 ad-spec';
        specElement.innerHTML = `
            <div class="ad-spec-title">${key}</div>
            <div class="ad-spec-value">${value}</div>
        `;
        container.appendChild(specElement);
    }
}

function toggleFavorite(adId) {
    // Здесь будет логика добавления/удаления из избранного
    const btn = document.getElementById('add-to-favorites');
    const isFavorite = btn.classList.contains('active');
    
    if (isFavorite) {
        btn.classList.remove('active', 'btn-danger');
        btn.classList.add('btn-outline-danger');
        btn.innerHTML = '<i class="bi bi-heart"></i>';
    } else {
        btn.classList.add('active', 'btn-danger');
        btn.classList.remove('btn-outline-danger');
        btn.innerHTML = '<i class="bi bi-heart-fill"></i>';
    }
    
}