document.addEventListener('DOMContentLoaded', function() {
    const submitBtn = document.getElementById('submitAd');
    const adForm = document.getElementById('adForm');
    
    // Обработчик отправки формы
    submitBtn.addEventListener('click', function() {
        // Валидация формы
        if (!adForm.checkValidity()) {
            adForm.classList.add('was-validated');
            return;
        }
        
        // Сбор данных формы
        const formData = {
            title: document.getElementById('adTitle').value,
            description: document.getElementById('adDescription').value,
            type: document.querySelector('.type-select').value,
            category: document.querySelector('.category-select').value,
            price: document.getElementById('adPrice').value,
            image: document.getElementById('adImage').files[0]
        };
        
        // Здесь будет реальная отправка на сервер
        // Временно используем имитацию
        simulateAdCreation(formData);
    });
    
    // Функция имитации создания объявления
    function simulateAdCreation(formData) {
        console.log('Отправка данных:', formData);
        
        // Имитация задержки сети
        setTimeout(() => {
            Swal.fire({
                title: 'Успех!',
                text: 'Объявление успешно создано',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(() => {
                // Закрытие модального окна
                const modal = bootstrap.Modal.getInstance(document.getElementById('newAdModal'));
                modal.hide();
                
                // Сброс формы
                adForm.reset();
                adForm.classList.remove('was-validated');
                
                // Обновление UI
                updateUIAfterCreation();
            });
        }, 1000);
    }
    
    // Обновление интерфейса после создания объявления
    function updateUIAfterCreation() {
        const alertBox = document.querySelector('.alert-info');
        alertBox.textContent = 'Объявление создано! Оно появится в списке после модерации.';
        alertBox.classList.remove('alert-info');
        alertBox.classList.add('alert-success');
        
        // Здесь можно добавить обновление списка объявлений
    }
    
    // Обработчик для загрузки изображения
    document.getElementById('adImage').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) {
                Swal.fire({
                    title: 'Ошибка',
                    text: 'Файл слишком большой. Максимальный размер: 5MB',
                    icon: 'error'
                });
                e.target.value = '';
            }
        }
    });
});