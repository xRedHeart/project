<?php
ob_start(); 
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Разрешённые категории
$allowedCategories = [
    'Все', 'Электроника', 'Авто', 'Одежда', 
    'Мебель', 'Недвижимость', 'Животные', 'Запчасти'
];

try {
    $db = new PDO(
        "pgsql:host=localhost;port=5432;dbname=projectX", 
        "postgres", 
        "KaFFko645321",
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

    session_start();

    // Валидация параметров
    $minPrice = filter_input(INPUT_GET, 'min_price', FILTER_VALIDATE_FLOAT, ['options' => ['default' => 0]]);
    $maxPrice = filter_input(INPUT_GET, 'max_price', FILTER_VALIDATE_FLOAT, ['options' => ['default' => 20000]]);
    $category = filter_input(INPUT_GET, 'category', FILTER_UNSAFE_RAW);
    $type = filter_input(INPUT_GET, 'type', FILTER_UNSAFE_RAW);
    $user_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    $page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, ['options' => ['default' => 1, 'min_range' => 1]]);
    $perPage = filter_input(INPUT_GET, 'perPage', FILTER_VALIDATE_INT, ['options' => ['default' => 10, 'min_range' => 1]]);
    $searchQuery = filter_input(INPUT_GET, 'search', FILTER_UNSAFE_RAW, ['options' => ['default' => '']]);

    // Проверка категории
    if ($category && !in_array($category, $allowedCategories)) {
        $category = 'Все';
    }

    // Базовый SQL
    $sql = "SELECT id, title, description, price, category, services, products, image, 
                   TO_CHAR(created_at, 'YYYY-MM-DD HH24:MI:SS') as created_at
            FROM ads 
            WHERE price BETWEEN :min_price AND :max_price";
    $params = [
        ':min_price' => $minPrice,
        ':max_price' => $maxPrice
    ];

    // Фильтр по категории (если не "Все")
    if ($category && $category !== 'Все') {
        $sql .= " AND category = :category";
        $params[':category'] = $category;
    }

    if (!empty($searchQuery)) {
        $sql .= " AND title ILIKE :search";
        $params[':search'] = '%' . $searchQuery . '%';
    }

    // Фильтр по типу (услуги/товары)
    if ($type === 'services') {
        $sql .= " AND services IS TRUE";
    } elseif ($type === 'products') {
        $sql .= " AND products IS TRUE";
    }

    // Пагинация
    $offset = ($page - 1) * $perPage;
    $sql .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
    $params[':limit'] = $perPage;
    $params[':offset'] = $offset;

    $countSql = "SELECT COUNT(*) FROM ads WHERE price BETWEEN :min_price AND :max_price";

    $stmt = $db->prepare($sql);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
    }
    $stmt->execute();
    $ads = $stmt->fetchAll();

    $countSql = "SELECT COUNT(*) FROM ads WHERE price BETWEEN :min_price AND :max_price";
    if ($category && $category !== 'Все') {
        $countSql .= " AND category = :category";
    }
    if ($type === 'services') {
        $countSql .= " AND services IS TRUE";
    } elseif ($type === 'products') {
        $countSql .= " AND products IS TRUE";
    }
    if (!empty($searchQuery)) {
        $countSql .= " AND title ILIKE :search";
    }

    $countStmt = $db->prepare($countSql);
    foreach ($params as $key => $value) {
        if (!in_array($key, [':limit', ':offset'])) {
            $countStmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
    }
    $countStmt->execute();
    $total = $countStmt->fetchColumn();

    // Ответ
    echo json_encode([
        'success' => true,
        'ads' => $ads,
        'total' => (int)$total,
        'page' => $page,
        'perPage' => $perPage,
        'totalPages' => ceil($total / $perPage),
        'filters' => [
            'current_category' => $category,
            'current_type' => $type,
            'allowed_categories' => $allowedCategories
        ]
    ]);

} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Ошибка базы данных'
    ]);
    exit; 
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_clean();
    try {
        // Проверка авторизации
        if (!isset($_SESSION['user_id'])) {
            throw new Exception('Для добавления объявления необходимо авторизоваться');
        }
        
        $data = $_POST;
        if (empty($_POST)) {
            $input = file_get_contents('php://input');
            $data = json_decode($input, true) ?? [];
        }
        
        // Валидация данных
        if (empty($data['title']) || empty($data['category']) || !isset($data['price'])) {
            throw new Exception('Не заполнены обязательные поля');
        }
        
        // Подготовка SQL
        $sql = "INSERT INTO ads (title, description, category, price, services, products, image, user_id) 
                VALUES (:title, :description, :category, :price, :services, :products, :image, :user_id)";
        
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':title', $data['title']);
        $stmt->bindValue(':description', $data['description'] ?? '');
        $stmt->bindValue(':category', $data['category']);
        $stmt->bindValue(':price', $data['price']);
        $stmt->bindValue(':services', $data['type'] === 'services', PDO::PARAM_BOOL);
        $stmt->bindValue(':products', $data['type'] === 'products', PDO::PARAM_BOOL);
        $stmt->bindValue(':image', $data['image'] ?? null);
        $stmt->bindValue(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        
        $stmt->execute();
        
        echo json_encode([
            'success' => true,
            'message' => 'Объявление успешно создано',
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
    exit;
}
elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    ob_clean();
    try {
        $adId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        if (!$adId) {
            throw new Exception('Неверный ID объявления');
        }

        $stmt = $db->prepare("
            SELECT id, title, description, price, category, services, products, image, 
                   TO_CHAR(created_at, 'YYYY-MM-DD HH24:MI:SS') as created_at
            FROM ads 
            WHERE id = :id
        ");
        $stmt->bindValue(':id', $adId, PDO::PARAM_INT);
        $stmt->execute();
        $ad = $stmt->fetch();

        if (!$ad) {
            throw new Exception('Объявление не найдено');
        }

        echo json_encode([
            'success' => true,
            'ad' => $ad
        ]);
        exit;

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
        exit;
    }
}
