<?php
ob_start();
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    $db = new PDO(
        "pgsql:host=localhost;port=5432;dbname=projectX", 
        "postgres", 
        "KaFFko645321",
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (isset($input['action'])) {
            switch ($input['action']) {
                case 'register':
                    handleRegister($db, $input);
                    break;
                case 'login':
                    handleLogin($db, $input);
                    break;
                case 'logout':
                    handleLogout();
                    break;
                case 'check_auth':
                    checkAuth();
                    break;
                default:
                    echo json_encode(['success' => false, 'message' => 'Неизвестное действие']);
            }
        }
    }
} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Ошибка базы данных']);
}

function handleRegister($db, $data) {
    if (empty($data['username']) || empty($data['email']) || empty($data['password'])) {
        echo json_encode(['success' => false, 'message' => 'Все поля обязательны для заполнения']);
        return;
    }

    // Проверка существующего пользователя
    $stmt = $db->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
    $stmt->execute([':username' => $data['username'], ':email' => $data['email']]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Пользователь с таким именем или email уже существует']);
        return;
    }

    // Хеширование пароля
    $passwordHash = password_hash($data['password'], PASSWORD_DEFAULT);
    
    // Создание пользователя
    $stmt = $db->prepare("INSERT INTO users (username, email, password_hash) VALUES (:username, :email, :password_hash)");
    $stmt->execute([
        ':username' => $data['username'],
        ':email' => $data['email'],
        ':password_hash' => $passwordHash
    ]);
    
    // Автоматический вход после регистрации
    $userId = $db->lastInsertId();
    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $data['username'];
    
    echo json_encode([
        'success' => true,
        'message' => 'Регистрация успешна',
        'user' => [
            'id' => $userId,
            'username' => $data['username'],
            'email' => $data['email']
        ]
    ]);
}

function handleLogin($db, $data) {
    if (empty($data['email']) || empty($data['password'])) {
        echo json_encode(['success' => false, 'message' => 'Email и пароль обязательны']);
        return;
    }

    $stmt = $db->prepare("SELECT id, username, email, password_hash FROM users WHERE email = :email");
    $stmt->execute([':email' => $data['email']]);
    $user = $stmt->fetch();
    
    if (!$user || !password_verify($data['password'], $user['password_hash'])) {
        echo json_encode(['success' => false, 'message' => 'Неверный email или пароль']);
        return;
    }
    
    session_start();
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    
    echo json_encode([
        'success' => true,
        'message' => 'Вход выполнен успешно',
        'user' => [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email']
        ]
    ]);
}

function handleLogout() {
    session_start();
    session_unset();
    session_destroy();
    echo json_encode(['success' => true, 'message' => 'Выход выполнен']);
}

function checkAuth() {
    session_start();
    if (isset($_SESSION['user_id'])) {
        echo json_encode([
            'success' => true,
            'isLoggedIn' => true,
            'user' => [
                'id' => $_SESSION['user_id'],
                'username' => $_SESSION['username']
            ]
        ]);
    } else {
        echo json_encode(['success' => true, 'isLoggedIn' => false]);
    }
}