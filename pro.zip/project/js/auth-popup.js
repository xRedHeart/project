document.addEventListener('DOMContentLoaded', function() {
    checkAuthStatus();
    
    document.getElementById('login-box').querySelector('button').addEventListener('click', handleLogin);
    document.getElementById('register-box').querySelector('button').addEventListener('click', handleRegister);
    
    const logoutBtn = document.querySelector('.dropdown-item[href="#"]');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            handleLogout();
        });
    }
});

function toggleLogin() {
    const login = document.getElementById('login-box');
    const register = document.getElementById('register-box');
    login.style.display = (login.style.display === 'none' || login.style.display === '') ? 'block' : 'none';
    register.style.display = 'none';
}

function toggleRegister() {
    const login = document.getElementById('login-box');
    const register = document.getElementById('register-box');
    register.style.display = (register.style.display === 'none' || register.style.display === '') ? 'block' : 'none';
    login.style.display = 'none';
}

async function checkAuthStatus() {
    try {
        const response = await fetch('/api/auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ action: 'check_auth' })
        });
        
        const data = await response.json();
        
        if (data.success && data.isLoggedIn) {
            updateUIForLoggedInUser(data.user);
        } else {
            updateUIForGuest();
        }
    } catch (error) {
        console.error('Ошибка проверки авторизации:', error);
    }
}

async function handleLogin() {
    const loginBox = document.getElementById('login-box');
    const email = loginBox.querySelector('input[type="email"]').value;
    const password = loginBox.querySelector('input[type="password"]').value;
    
    try {
        const response = await fetch('/api/auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'login',
                email: email,
                password: password
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            updateUIForLoggedInUser(data.user);
            toggleLogin();
            showSuccessMessage('Вход выполнен успешно');
            window.location.reload();
        } else {
            showErrorMessage(data.message || 'Ошибка входа');
        }
    } catch (error) {
        console.error('Ошибка входа:', error);
        showErrorMessage('Ошибка соединения с сервером');
    }
}

async function handleRegister() {
    const registerBox = document.getElementById('register-box');
    const username = registerBox.querySelector('input[type="text"]').value;
    const email = registerBox.querySelector('input[type="email"]').value;
    const password = registerBox.querySelector('input[type="password"]').value;
    
    try {
        const response = await fetch('/api/auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'register',
                username: username,
                email: email,
                password: password
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            updateUIForLoggedInUser(data.user);
            toggleRegister();
            showSuccessMessage('Регистрация успешна');
            window.location.reload();
        } else {
            showErrorMessage(data.message || 'Ошибка регистрации');
        }
    } catch (error) {
        console.error('Ошибка регистрации:', error);
        showErrorMessage('Ошибка соединения с сервером');
    }
}

async function handleLogout() {
    try {
        const response = await fetch('/api/auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ action: 'logout' })
        });
        
        const data = await response.json();
        
        if (data.success) {
            updateUIForGuest();
            showSuccessMessage('Выход выполнен успешно');
            window.location.reload();
        }
    } catch (error) {
        console.error('Ошибка выхода:', error);
    }
}

function updateUIForLoggedInUser(user) {
    const guest = document.getElementById('guest-actions');
    const userInfo = document.getElementById('user-info');
    
    guest.style.display = 'none';
    userInfo.classList.remove('d-none');
    document.getElementById('user-name').textContent = user.username;
    document.getElementById('user-avatar').src = 'images/aNNqp9.jpeg'; 
    
    document.getElementById('login-box').style.display = 'none';
    document.getElementById('register-box').style.display = 'none';
}

function updateUIForGuest() {
    const guest = document.getElementById('guest-actions');
    const userInfo = document.getElementById('user-info');
    
    guest.style.display = 'flex';
    userInfo.classList.add('d-none');
}

function showSuccessMessage(message) {
    console.log('Success:', message);
}

function showErrorMessage(message) {
    console.error('Error:', message);
}

document.addEventListener('click', function (e) {
    if (!e.target.closest('.auth-box') &&
        !e.target.closest('button[onclick="toggleLogin()"]') &&
        !e.target.closest('button[onclick="toggleRegister()"]')) {
        document.getElementById('login-box').style.display = 'none';
        document.getElementById('register-box').style.display = 'none';
    }
});