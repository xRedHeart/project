/**
 * Скрипт для фильтрации объявлений с пагинацией
 * Обрабатывает: 
 * - Фильтр по цене (диапазон)
 * - Фильтр по категории
 * - Фильтр по типу (услуги/товары)
 * - Пагинацию
 */

document.addEventListener('DOMContentLoaded', function() {
    // Элементы DOM
    const rangeInput = document.querySelectorAll(".range-input input"),
          priceInput = document.querySelectorAll(".price-input input"),
          range = document.querySelector(".slider .progress"),
          categorySelect = document.querySelector(".category-select"),
          typeSelect = document.querySelector(".type-select"),
          adsContainer = document.querySelector("#ads-container"),
          pagination = document.querySelector("#pagination"),
          applyFiltersBtn = document.querySelector("#apply-filters");
    
    // Переменные состояния
    let priceGap = 1000;
    let currentPage = 1;
    let totalPages = 1;
    let isLoading = false;

    // Инициализация слайдера цен
    function initPriceSlider() {
        range.style.left = "0%";
        range.style.right = "0%";
        
        // Обработчики для ползунков
        rangeInput.forEach(input => {
            input.addEventListener("input", function(e) {
                let minVal = parseInt(rangeInput[0].value),
                    maxVal = parseInt(rangeInput[1].value);

                if ((maxVal - minVal) < priceGap) {
                    if (e.target.className === "range-min") {
                        rangeInput[0].value = maxVal - priceGap;
                    } else {
                        rangeInput[1].value = minVal + priceGap;
                    }
                } else {
                    priceInput[0].value = minVal;
                    priceInput[1].value = maxVal;
                    range.style.left = ((minVal / rangeInput[0].max) * 100) + "%";
                    range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
                }
            });
        });

        // Обработчики для числовых полей
        priceInput.forEach(input => {
            input.addEventListener("input", function(e) {
                let minPrice = parseInt(priceInput[0].value),
                    maxPrice = parseInt(priceInput[1].value);
                
                if ((maxPrice - minPrice >= priceGap) && maxPrice <= 10000) {
                    if (e.target.className.includes("input-min")) {
                        rangeInput[0].value = minPrice;
                        range.style.left = ((minPrice / 10000) * 100) + "%";
                    } else {
                        rangeInput[1].value = maxPrice;
                        range.style.right = 100 - (maxPrice / 10000) * 100 + "%";
                    }
                }
            });
        });
    }
    
    // Загрузка объявлений с сервера
    async function loadAds(page = 1) {
        if (isLoading) return;
        
        isLoading = true;
        currentPage = page;
        
        const minPrice = priceInput[0].value || 0;
        const maxPrice = priceInput[1].value || 10000;
        const category = categorySelect.value;
        const type = typeSelect.value;
        
        try {
            // Показываем индикатор загрузки
            adsContainer.innerHTML = `
                <div class="col-12 text-center my-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Загрузка...</span>
                    </div>
                    <p class="mt-2">Загрузка объявлений...</p>
                </div>
            `;
            
            const response = await fetch(
                `/api/ads.php?min_price=${minPrice}&max_price=${maxPrice}&category=${encodeURIComponent(category)}&type=${type}&page=${page}`
            );
            
            if (!response.ok) throw new Error('Ошибка сети');
            
            const data = await response.json();
            
            if (data.success) {
                renderAds(data.ads);
                totalPages = Math.ceil(data.total / data.perPage);
                renderPagination();
            } else {
                throw new Error(data.message || 'Неизвестная ошибка сервера');
            }
        } catch (error) {
            console.error('Ошибка загрузки объявлений:', error);
            adsContainer.innerHTML = `
                <div class="col-12 alert alert-danger">
                    Ошибка загрузки: ${error.message}
                </div>
            `;
        } finally {
            isLoading = false;
        }
    }

    // Отрисовка объявлений
    function renderAds(ads) {
        if (currentPage === 1) {
            adsContainer.innerHTML = '';
        }
        
        if (ads.length === 0 && currentPage === 1) {
            adsContainer.innerHTML = `
                <div class="col-12 alert alert-info">
                    Объявления не найдены. Попробуйте изменить параметры поиска.
                </div>
            `;
            return;
        }

        let html = '';
        
        ads.forEach(ad => {
            const typeBadge = ad.services ? 
                '<span class="badge bg-success me-1">Услуга</span>' : 
                '<span class="badge bg-primary me-1">Товар</span>';
            
            const adImage = ad.image 
                ? `uploads/${ad.image}`
                : 'https://via.placeholder.com/300';
            
            html += `
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100 ad-card">
                        <img src="${adImage}" class="card-img-top ad-img" alt="${ad.title}" loading="lazy">
                        <div class="card-body">
                            <h5 class="card-title">${ad.title}</h5>
                            <div class="d-flex justify-content-between mb-2">
                                ${typeBadge}
                                <span class="badge bg-secondary">${ad.category}</span>
                            </div>
                            <p class="card-text text-truncate">${ad.description || 'Нет описания'}</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    ${new Date(ad.created_at).toLocaleDateString('ru-RU')}
                                </small>
                                <h5 class="text-primary mb-0">${parseInt(ad.price).toLocaleString('ru-RU')} ₽</h5>
                            </div>
                        </div>
                        <a href="ad.html?id=${ad.id}" class="stretched-link"></a>
                    </div>
                </div>
            `;
        });
        
        if (currentPage > 1) {
            adsContainer.insertAdjacentHTML('beforeend', html);
        } else {
            adsContainer.innerHTML = `<div class="row">${html}</div>`;
        }
    }

    // Отрисовка пагинации
    function renderPagination() {
        if (totalPages <= 1) {
            pagination.innerHTML = '';
            return;
        }

        let html = '';
        const maxVisiblePages = 5;
        let startPage = Math.max(1, currentPage - 2);
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

        // Кнопка "Назад"
        html += `
            <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${currentPage - 1}" aria-label="Назад">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
        `;

        // Первая страница
        if (startPage > 1) {
            html += `
                <li class="page-item">
                    <a class="page-link" href="#" data-page="1">1</a>
                </li>
                ${startPage > 2 ? '<li class="page-item disabled"><span class="page-link">...</span></li>' : ''}
            `;
        }

        // Страницы
        for (let i = startPage; i <= endPage; i++) {
            html += `
                <li class="page-item ${i === currentPage ? 'active' : ''}">
                    <a class="page-link" href="#" data-page="${i}">${i}</a>
                </li>
            `;
        }

        // Последняя страница
        if (endPage < totalPages) {
            html += `
                ${endPage < totalPages - 1 ? '<li class="page-item disabled"><span class="page-link">...</span></li>' : ''}
                <li class="page-item">
                    <a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a>
                </li>
            `;
        }

        // Кнопка "Вперед"
        html += `
            <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${currentPage + 1}" aria-label="Вперед">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        `;

        pagination.innerHTML = html;

        // Обработчики событий для пагинации
        document.querySelectorAll('[data-page]').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const page = parseInt(this.dataset.page);
                if (!isNaN(page) && page !== currentPage) {
                    loadAds(page);
                    window.scrollTo({top: 0, behavior: 'smooth'});
                }
            });
        });
    }

    // Инициализация
    function init() {
        initPriceSlider();
        loadAds();

        // Обработчики событий
        applyFiltersBtn.addEventListener('click', () => {
            currentPage = 1;
            loadAds();
        });

        categorySelect.addEventListener('change', () => {
            currentPage = 1;
            loadAds();
        });

        typeSelect.addEventListener('change', () => {
            currentPage = 1;
            loadAds();
        });
    }

    // Запуск
    init();
});